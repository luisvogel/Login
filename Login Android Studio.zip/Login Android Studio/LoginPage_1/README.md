# MyLoginApp

Simple Login Design for android app

Full Video Tutorial is available in Youtube Link : https://youtu.be/sOJRJtM_iu0

![LOGIN](https://user-images.githubusercontent.com/68380115/126171145-4212b2e5-db0a-41b3-b18a-5697222f2596.PNG)
